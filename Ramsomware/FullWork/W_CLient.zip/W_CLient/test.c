#include <openssl/ssl.h>

int main() {
    SSL_library_init();
    // Resto de tu código de prueba aquí
    return 0;
}

